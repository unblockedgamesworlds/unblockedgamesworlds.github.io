window.game = new CatchTheCatGame({
    w: 11,
    h: 11,
    r: 20,
    backgroundColor: '#ffffff',
    parent: 'cat',
    statusBarAlign: 'center',
    credit: ''
});